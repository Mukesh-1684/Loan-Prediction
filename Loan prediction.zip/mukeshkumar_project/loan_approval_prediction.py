import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

def load_data(filepath):
    return pd.read_csv(filepath)

def preprocess_data(df):
    df = df.drop('Loan_ID', axis=1)

    # Fill missing values
    df["Gender"] = df["Gender"].fillna(df["Gender"].mode()[0])
    df["Married"] = df["Married"].fillna(df["Married"].mode()[0])
    df["Dependents"] = df["Dependents"].fillna(df["Dependents"].mode()[0])
    df["Self_Employed"] = df["Self_Employed"].fillna(df["Self_Employed"].mode()[0])
    df["LoanAmount"] = df["LoanAmount"].fillna(df["LoanAmount"].median())
    df["Loan_Amount_Term"] = df["Loan_Amount_Term"].fillna(df["Loan_Amount_Term"].mode()[0])
    df["Credit_History"] = df["Credit_History"].fillna(df["Credit_History"].mode()[0])

    return df

def perform_eda(df):
    # Loan Status Distribution
    Loan_status_count = df["Loan_Status"].value_counts()
    plt.pie(Loan_status_count, labels=Loan_status_count.index, autopct="%1.1f%%")
    plt.title("LoanStatus Distribution")
    plt.legend(title="Category")
    plt.show()

    # Gender Distribution
    gender_count = df["Gender"].value_counts()
    plt.figure(figsize=(8, 6))
    plt.bar(gender_count.index, gender_count.values)
    plt.xlabel("Gender")
    plt.ylabel("Count")
    plt.title("Gender Distribution")
    plt.show()

    # Married status Distribution
    married_count = df["Married"].value_counts()
    plt.figure(figsize=(8, 6))
    plt.bar(married_count.index, married_count.values)
    plt.title("Married status Distribution")
    plt.show()

    # Education Distribution
    education_count = df["Education"].value_counts()
    plt.bar(education_count.index, education_count.values)
    plt.title("Education Distribution")
    plt.show()

    # Self-employment Distribution
    self_employment_count = df["Self_Employed"].value_counts()
    plt.bar(self_employment_count.index, self_employment_count.values)
    plt.title("Self-employment Distribution")
    plt.show()

    # Application Income Distribution
    plt.hist(df["ApplicantIncome"], bins="auto")
    plt.title("Application Income Distribution")
    plt.show()

    # Loan_status vs ApplicantIncome
    sns.boxplot(x="Loan_Status", y="ApplicantIncome", showmeans=True, data=df)
    plt.title("Loan_status vs ApplicantIncome")
    plt.show()

def handle_outliers(df, column_name):
    Q1 = df[column_name].quantile(0.25)
    Q3 = df[column_name].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    df = df[(df[column_name] >= lower_bound) & (df[column_name] <= upper_bound)]
    return df

def plot_box(df, x, y, hue=None):
    sns.boxplot(data=df, x=x, y=y, hue=hue)
    plt.title(f'{x} vs {y}')
    plt.xlabel(x)
    plt.ylabel(y)
    plt.show()

def plot_hist(df, x, hue=None):
    sns.histplot(data=df, x=x, hue=hue, multiple='dodge', shrink=0.8)
    plt.title(f'Loan_Status vs {x}')
    plt.xlabel(x)
    plt.ylabel('Count')
    plt.show()

def train_model(df):
    cat_cols = ['Gender', 'Married', 'Dependents', 'Education', 'Self_Employed', 'Property_Area']
    df = pd.get_dummies(df, columns=cat_cols)

    X = df.drop('Loan_Status', axis=1)
    y = df['Loan_Status']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    numerical_cols = ['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term', 'Credit_History']
    X_train[numerical_cols] = scaler.fit_transform(X_train[numerical_cols])
    X_test[numerical_cols] = scaler.transform(X_test[numerical_cols])

    model = SVC(random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    return X_test, y_pred

# Main execution
df = pd.read_csv("loan_prediction.csv")

# Data Preprocessing
df = preprocess_data(df)

# Exploratory Data Analysis
perform_eda(df)

# Handling Outliers
df = handle_outliers(df, 'ApplicantIncome')
plot_box(df, 'Loan_Status', 'CoapplicantIncome', 'Loan_Status')
df = handle_outliers(df, 'CoapplicantIncome')
plot_box(df, 'Loan_Status', 'LoanAmount', 'Loan_Status')

# Other Plots
plot_hist(df, 'Credit_History', 'Loan_Status')
plot_hist(df, 'Property_Area', 'Loan_Status')

# Model Training
X_test, y_pred = train_model(df)

# Convert X_test to a DataFrame and add the predicted values
X_test_df = pd.DataFrame(X_test, columns=X_test.columns)
X_test_df['Loan_Status_Predicted'] = y_pred
print(X_test_df.head())
